import React from 'react';

const FinalRewardScreen: React.FC = () => {
    return (
        <div className='final-reward'>

        </div>
    );
};

export default FinalRewardScreen;
